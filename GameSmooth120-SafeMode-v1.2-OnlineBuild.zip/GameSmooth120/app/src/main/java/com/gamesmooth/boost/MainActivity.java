package com.gamesmooth.boost;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView displayInfo, thermalInfo, batteryInfo, message;
    private float selectedHz = 60f;
    private final String[] sensitivityNames = {"General", "Red Dot", "2x Scope", "4x Scope", "Sniper", "Free Look"};
    private final int[] sensitivityValues = {190, 185, 178, 165, 110, 175};

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setNavigationBarColor(0xFF080D0B);
        buildUi();
        refreshStatus();
    }

    @Override protected void onResume() { super.onResume(); if (displayInfo != null) refreshStatus(); }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(0xFF080D0B);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(24), dp(20), dp(28));
        scroll.addView(root);
        TextView title = text("GAME SMOOTH 120", 26, 0xFFFFFFFF); title.setGravity(Gravity.CENTER); title.setTypeface(null, 1); root.addView(title);
        TextView subtitle = text("SAFE GAMING MODE  •  REDMI 14C 5G  •  V1.2", 12, 0xFF7EDFA5); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0, dp(8), 0, dp(20)); root.addView(subtitle);

        LinearLayout card = card(root, "DISPLAY REFRESH RATE");
        displayInfo = text("Checking supported display modes…", 14, 0xFFE2E8E4); displayInfo.setPadding(0, dp(8), 0, dp(12)); card.addView(displayInfo);
        LinearLayout modes = new LinearLayout(this); modes.setOrientation(LinearLayout.HORIZONTAL); card.addView(modes);
        for (int hz : new int[]{60, 90, 120}) { Button b = button(hz + " Hz"); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(48), 1); p.setMargins(dp(3), 0, dp(3), 0); modes.addView(b,p); b.setOnClickListener(v -> setRefreshRate(hz)); }

        LinearLayout health = card(root, "DEVICE SAFETY");
        thermalInfo = text("Thermal status: checking", 14, 0xFFE2E8E4); thermalInfo.setPadding(0, dp(8), 0, dp(6)); health.addView(thermalInfo);
        batteryInfo = text("Battery temperature: checking", 14, 0xFFE2E8E4); health.addView(batteryInfo);
        TextView safety = text("This app does not overclock, change CPU/GPU voltage, kill other apps, or run a constant background booster. Android manages processor load and thermal protection.", 12, 0xFF9EAAA2); safety.setPadding(0, dp(12), 0, 0); health.addView(safety);

        LinearLayout performance = card(root, "SMART PERFORMANCE");
        TextView perfText = text("CPU/GPU load is managed by Android and the game. Standard apps cannot safely force processor clocks or reliably read all GPU metrics. This app stays idle unless you open it, avoiding extra gaming-time load.", 13, 0xFFE2E8E4);
        perfText.setPadding(0, dp(8), 0, dp(4)); performance.addView(perfText);
        TextView perfNote = text("For smoother play: use Smooth graphics, select the highest in-game FPS option your device offers, close apps you are not using, and stop playing if the phone becomes hot.", 12, 0xFF9EAAA2);
        perfNote.setPadding(0, dp(4), 0, 0); performance.addView(perfNote);

        LinearLayout sens = card(root, "FREE FIRE SENSITIVITY PRESET • NO DPI");
        TextView sensIntro = text("Editable starting point for 3-finger freestyle. These values are a guide only; they are not automatically applied inside Free Fire.", 12, 0xFF9EAAA2);
        sens.addView(sensIntro);
        for (int i = 0; i < sensitivityNames.length; i++) {
            final int index = i;
            TextView label = text(sensitivityNames[i] + ": " + sensitivityValues[i], 14, 0xFFE2E8E4);
            label.setPadding(0, dp(10), 0, 0); sens.addView(label);
            SeekBar seek = new SeekBar(this); seek.setMax(200); seek.setProgress(sensitivityValues[i]); sens.addView(seek);
            seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override public void onProgressChanged(SeekBar bar, int value, boolean user) { sensitivityValues[index] = value; label.setText(sensitivityNames[index] + ": " + value); }
                @Override public void onStartTrackingTouch(SeekBar bar) {}
                @Override public void onStopTrackingTouch(SeekBar bar) {}
            });
        }
        addAction(sens, "COPY SENSITIVITY VALUES", () -> {
            StringBuilder values = new StringBuilder("Game Smooth 120 — FF sensitivity\n");
            for (int i = 0; i < sensitivityNames.length; i++) values.append(sensitivityNames[i]).append(": ").append(sensitivityValues[i]).append("\n");
            ClipboardManager clipboard = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("FF sensitivity", values.toString()));
            message.setText("Sensitivity values copied. Enter them manually in Free Fire.");
        });

        LinearLayout tools = card(root, "QUICK TOOLS");
        addAction(tools, "OPEN FREE FIRE", this::launchGame);
        addAction(tools, "BATTERY & BACKGROUND SETTINGS", this::openBatterySettings);
        addAction(tools, "DISPLAY SETTINGS", this::openDisplaySettings);
        message = text("Ready. Choose a display mode supported by your phone.", 13, 0xFF7EDFA5); message.setGravity(Gravity.CENTER); message.setPadding(0, dp(18), 0, 0); root.addView(message);
        setContentView(scroll);
    }
    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16), dp(14), dp(16), dp(16)); box.setBackgroundColor(0xFF17211B);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, dp(8), 0, dp(8)); parent.addView(box, lp);
        TextView h = text(heading, 13, 0xFF7EDFA5); h.setTypeface(null, 1); box.addView(h); return box;
    }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(13); return b; }
    private void addAction(LinearLayout parent, String label, Runnable action) { Button b = button(label); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(50)); lp.setMargins(0, dp(5), 0, dp(5)); parent.addView(b, lp); b.setOnClickListener(v -> action.run()); }

    private void refreshStatus() {
        Display d = getWindowManager().getDefaultDisplay(); StringBuilder s = new StringBuilder("Supported modes: ");
        if (Build.VERSION.SDK_INT >= 23) { for (Display.Mode m : d.getSupportedModes()) s.append(String.format(Locale.US, "%.0f Hz  ", m.getRefreshRate())); }
        else s.append(String.format(Locale.US, "%.0f Hz", d.getRefreshRate()));
        displayInfo.setText(s.toString());
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (battery != null) { int temp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1); batteryInfo.setText(temp >= 0 ? String.format(Locale.US, "Battery temperature: %.1f°C", temp / 10f) : "Battery temperature unavailable"); }
        if (Build.VERSION.SDK_INT >= 29) {
            PowerManager pm = (PowerManager)getSystemService(POWER_SERVICE); int t = pm.getCurrentThermalStatus();
            String[] labels = {"None", "Light", "Moderate", "Severe", "Critical", "Emergency", "Shutdown"};
            int idx = Math.max(0, Math.min(t, labels.length - 1)); thermalInfo.setText("Android thermal status: " + labels[idx] + (t >= PowerManager.THERMAL_STATUS_SEVERE ? " — reduce game load and let the phone cool." : ""));
            thermalInfo.setTextColor(t >= PowerManager.THERMAL_STATUS_SEVERE ? 0xFFFF8A65 : 0xFFE2E8E4);
        } else thermalInfo.setText("Thermal status: not exposed by this Android version");
    }
    private void setRefreshRate(int hz) {
        selectedHz = hz; Display d = getWindowManager().getDefaultDisplay();
        if (Build.VERSION.SDK_INT >= 23) { Display.Mode best = null; float diff = Float.MAX_VALUE; for (Display.Mode m : d.getSupportedModes()) { float x = Math.abs(m.getRefreshRate() - hz); if (x < diff) { diff = x; best = m; } }
            if (best != null && diff < 3f) { WindowManager.LayoutParams p = getWindow().getAttributes(); p.preferredDisplayModeId = best.getModeId(); if (Build.VERSION.SDK_INT >= 30) p.preferredRefreshRate = hz; getWindow().setAttributes(p); message.setText("Requested " + hz + " Hz for this app. The phone may choose another mode, and this does not unlock game FPS."); }
            else message.setText(hz + " Hz is not listed as a supported display mode on this device.");
        } else message.setText("Display mode selection requires Android 6.0 or later.");
        if (Settings.System.canWrite(this)) { try { Settings.System.putFloat(getContentResolver(), "peak_refresh_rate", hz); } catch (Exception ignored) {} }
        refreshStatus();
    }
    private void launchGame() { for (String pkg : new String[]{"com.dts.freefireth", "com.dts.freefiremax"}) { Intent i = getPackageManager().getLaunchIntentForPackage(pkg); if (i != null) { startActivity(i); return; } } message.setText("Free Fire was not found. Install the game first."); }
    private void openBatterySettings() { try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } }
    private void openDisplaySettings() { try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); } catch (Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } }
}
